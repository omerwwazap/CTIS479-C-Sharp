﻿function colorChY() {
    document.body.style.backgroundColor = 'yellow';

}
function colorChW() {
    document.body.style.backgroundColor = '';
}
