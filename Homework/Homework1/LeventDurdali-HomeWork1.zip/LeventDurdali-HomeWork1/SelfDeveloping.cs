﻿//8.Implement at least one interface with at least one method.
namespace LeventDurdali_HomeWork1
{
    public interface SelfDeveloping
    {
        void Car_Develop();
    }
}